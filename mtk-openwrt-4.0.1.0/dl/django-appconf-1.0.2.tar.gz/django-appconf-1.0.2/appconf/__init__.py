from __future__ import absolute_import
from .base import AppConf  # noqa

__version__ = "1.0.2"

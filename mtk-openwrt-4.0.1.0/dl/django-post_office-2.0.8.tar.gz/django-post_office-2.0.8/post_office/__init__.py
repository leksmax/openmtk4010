VERSION = (2, 0, 8)

from .backends import EmailBackend

default_app_config = 'post_office.apps.PostOfficeConfig'

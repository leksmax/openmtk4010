/* This file used by t/19INC.t */

#include <math.h>


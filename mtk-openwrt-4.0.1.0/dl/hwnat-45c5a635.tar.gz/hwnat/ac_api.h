#ifndef __AC_API
#define __AC_API

int SetAcEntry(struct ac_args *opt, unsigned int cmd);
int GetAcEntry(struct ac_args *opt, unsigned int cmd);
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#if !defined(CONFIG_SUPPORT_OPENWRT)
#include <linux/autoconf.h>
#endif

#include "nvram_env.h"
#include "nvram_srv_env.h"
#include "flash_api.h"

char libnvram_debug = 0;
#define LIBNV_PRINT(x, ...) do { if (libnvram_debug) printf("%s %d: " x, __FILE__, __LINE__, ## __VA_ARGS__); } while(0)
#define LIBNV_ERROR(x, ...) do { printf("%s %d: ERROR! " x, __FILE__, __LINE__, ## __VA_ARGS__); } while(0)

//x is the value returned if the check failed
#define LIBNV_CHECK_INDEX(x) do { \
	if (index < 0 || index >= FLASH_BLOCK_NUM+EXTEND_BLOCK_NUM) { \
		LIBNV_PRINT("index(%d) is out of range\n", index); \
		return x; \
	} \
} while (0)

#define LIBNV_CHECK_VALID() do { \
	if (!fb[index].valid) { \
		LIBNV_PRINT("fb[%d] invalid, init again\n", index); \
		__nvram_init(index); \
	} \
} while (0)

#define FREE(x) do { if (x != NULL) {free(x); x=NULL;} } while(0)

/*
 * 1. read env from flash
 * 2. parse entries
 * 3. save the entries to cache
 */
void __nvram_init(int index)
{
	unsigned long from;
	int i, len;
	char *p, *q;

	LIBNV_PRINT("--> nvram_init %d\n", index);
	LIBNV_CHECK_INDEX();

	if (fb[index].valid)
		return;

	//read crc from flash
	from = fb[index].flash_offset;
	len = sizeof(fb[index].env.crc);
	flash_read((char *)&fb[index].env.crc, from, len);

	//read data from flash
	from = from + len;
	len = fb[index].flash_max_len - len;
	fb[index].env.data = (char *)malloc(len + 1);
	flash_read(fb[index].env.data, from, len);

	//check crc
	//printf("crc shall be %08lx\n", crc32(0, (unsigned char *)fb[index].env.data, len));
	if (crc32(0, (unsigned char *)fb[index].env.data, len) != fb[index].env.crc) {
		LIBNV_PRINT("Bad CRC %lx, ignore values in flash.\n", fb[index].env.crc);
		FREE(fb[index].env.data);
		//empty cache
		fb[index].valid = 1;
		fb[index].dirty = 0;
		return;
	}

	fb[index].env.data[len] = '\0';
	//parse env to cache
	p = fb[index].env.data;
	for (i = 0; i < MAX_CACHE_ENTRY; i++) {
		if (NULL == (q = strchr(p, '='))) {
			LIBNV_PRINT("parsed failed - cannot find '='\n");
			break;
		}
		*q = '\0'; //strip '='
		fb[index].cache[i].name = strdup(p);
		//printf("  %d '%s'->", i, p);

		p = q + 1; //value
		if (NULL == (q = strchr(p, '\0'))) {
			LIBNV_PRINT("parsed failed - cannot find '\\0'\n");
			break;
		}
		fb[index].cache[i].value = strdup(p);
		//printf("'%s'\n", p);

		p = q + 1; //next entry
		if (p - fb[index].env.data + 1 >= len) //end of block
			break;
		if (*p == '\0') //end of env
			break;
	}
	if (i == MAX_CACHE_ENTRY)
		LIBNV_PRINT("run out of env cache, please increase MAX_CACHE_ENTRY\n");

	fb[index].valid = 1;
	fb[index].dirty = 0;

	FREE(fb[index].env.data); //free it to save momery
}

void __nvram_close(int index)
{
	int i;

	//system("echo '__nvram_close ' > /dev/console");
	LIBNV_PRINT("--> nvram_close %d\n", index);
	LIBNV_CHECK_INDEX();

	if (!fb[index].valid)
		return;
	if (fb[index].dirty)
		__nvram_commit(index);

	//free env
	FREE(fb[index].env.data);

	//free cache
	for (i = 0; i < MAX_CACHE_ENTRY; i++) {
		FREE(fb[index].cache[i].name);
		FREE(fb[index].cache[i].value);
	}

	fb[index].valid = 0;
}

int __nvram_get_flash_max_len(int index)
{
	LIBNV_CHECK_INDEX(index);

	LIBNV_CHECK_VALID();

	return fb[index].flash_max_len;
}

/*
 * return idx (0 ~ MAX_CACHE_ENTRY)
 * return -1 if no such value or empty cache
 */
static int __cache_idx(int index, char *name)
{
	int i;

	for (i = 0; i < MAX_CACHE_ENTRY; i++) {
		if (!fb[index].cache[i].name)
			return -1;
		if (!strcmp(name, fb[index].cache[i].name))
			return i;
	}
	return -1;
}

#if 0
const char *__nvram_get(int index, char *name)
{
	//LIBNV_PRINT("--> __nvram_get\n");

	__nvram_close(index);
	__nvram_init(index);

	return __nvram_bufget(index, name);
}

int __nvram_set(int index, char *name, char *value)
{
	//LIBNV_PRINT("--> __nvram_set\n");

	if (-1 == nvram_bufset(index, name, value))
		return -1;

	return __nvram_commit(index);
}
#endif

char const *__nvram_bufget(int index, char *name)
{
	int idx;
	static char const *ret;

	//LIBNV_PRINT("--> __nvram_bufget %d\n", index);
	LIBNV_CHECK_INDEX("");
	LIBNV_CHECK_VALID();


	idx = __cache_idx(index, name);

	if (-1 != idx) {
		if (fb[index].cache[idx].value) {
			//duplicate the value in case caller modify it.
			//The only caller, nvram_socket_srv, does not modify it.
			//ret = strdup(fb[index].cache[idx].value);
			ret = fb[index].cache[idx].value;
			LIBNV_PRINT("bufget %d '%s'->'%s'\n", index, name, ret);
			return ret;
		}
	}

	//no default value set?
	//btw, we don't return NULL anymore!
	LIBNV_PRINT("bufget %d '%s'->''(empty) Warning!\n", index, name);

	return "";
}

int __nvram_bufset(int index, char *name, char *value)
{
	int idx;

	//LIBNV_PRINT("--> __nvram_bufset\n");

	LIBNV_CHECK_INDEX(-1);
	LIBNV_CHECK_VALID();

	idx = __cache_idx(index, name);

	if (-1 == idx) {
		//find the first empty room
		for (idx = 0; idx < MAX_CACHE_ENTRY; idx++) {
			if (!fb[index].cache[idx].name)
				break;
		}
		//no any empty room
		if (idx == MAX_CACHE_ENTRY) {
			LIBNV_ERROR("run out of env cache, please increase MAX_CACHE_ENTRY:%d\n", MAX_CACHE_ENTRY);
			return -1;
		}
		fb[index].cache[idx].name = strdup(name);
		fb[index].cache[idx].value = strdup(value);
		fb[index].dirty = 1;
	}
	else {
		//abandon the previous value
		if(strcmp(fb[index].cache[idx].value, value)){
			FREE(fb[index].cache[idx].value);
			fb[index].cache[idx].value = strdup(value);
			fb[index].dirty = 1;
		}
	}
	LIBNV_PRINT("bufset %d '%s'->'%s'\n", index, name, value);
	return 0;
}

void __nvram_buflist(int index)
{
	int i;

	//LIBNV_PRINT("--> __nvram_buflist %d\n", index);
	LIBNV_CHECK_INDEX();
	LIBNV_CHECK_VALID();

	for (i = 0; i < MAX_CACHE_ENTRY; i++) {
		if (!fb[index].cache[i].name)
			break;
		//printf("  '%s'='%s'\n", fb[index].cache[i].name, fb[index].cache[i].value);
		fprintf(stdout, "%s=%s\n", fb[index].cache[i].name, fb[index].cache[i].value);
	}
}

void __nvram_buflist_to_str(int index, char *str, int str_len)
{
	int i, len;
	char *p;

	//LIBNV_PRINT("--> __nvram_buflist %d\n", index);
	LIBNV_CHECK_INDEX();
	LIBNV_CHECK_VALID();

	for (p = str, i = 0; i < MAX_CACHE_ENTRY; i++) {
		if (!fb[index].cache[i].name || !fb[index].cache[i].value)
			break;

		/* len = strlen("$name=$value\0") */
		len = strlen(fb[index].cache[i].name) + strlen(fb[index].cache[i].value) + 2;

		//printf("  '%s'='%s'\n", fb[index].cache[i].name, fb[index].cache[i].value);
		if (p + len > str + str_len){
			LIBNV_ERROR("str length:%x is not enough!", str_len);
		}

		snprintf(p, len, "%s=%s", fb[index].cache[i].name, fb[index].cache[i].value);
		p += len;
//		ret += snprintf(str + ret + 1, strlen - ret, "%s=%s", fb[index].cache[i].name, fb[index].cache[i].value);
	}
}

/*
 * write flash from cache
 */
int __nvram_commit(int index)
{
	unsigned long to;
	int i, len;
	char *p;

	//LIBNV_PRINT("--> __nvram_commit %d\n", index);
	LIBNV_CHECK_INDEX(-1);
	LIBNV_CHECK_VALID();

	if (!fb[index].dirty) {
		LIBNV_PRINT("nothing to be committed\n");
		return 0;
	}

	//system("echo '__nvram_commit ' > /dev/console");

	//construct env block
	len = fb[index].flash_max_len - sizeof(fb[index].env.crc);
	fb[index].env.data = (char *)malloc(len);
	bzero(fb[index].env.data, len);
	p = fb[index].env.data;
	for (i = 0; i < MAX_CACHE_ENTRY; i++) {
		int l;
		if (!fb[index].cache[i].name || !fb[index].cache[i].value)
			break;
		l = strlen(fb[index].cache[i].name) + strlen(fb[index].cache[i].value) + 2;
		if (p - fb[index].env.data + 2 >= fb[index].flash_max_len) {
			LIBNV_ERROR("BLK:%s index=%d, max_len=0x%lx  is not enough!",
					fb[index].name, index, fb[index].flash_max_len);
			FREE(fb[index].env.data);
			return -1;
		}
		snprintf(p, l, "%s=%s", fb[index].cache[i].name, fb[index].cache[i].value);
		p += l;
	}
	*p = '\0'; //ending null

	//calculate crc
	fb[index].env.crc = (unsigned long)crc32(0, (unsigned char *)fb[index].env.data, len);
	printf("Commit crc = %x\n", (unsigned int)fb[index].env.crc);

	//write crc to flash
	to = fb[index].flash_offset;
	len = sizeof(fb[index].env.crc);
	flash_write((char *)&fb[index].env.crc, to, len);

	//write data to flash
	to = to + len;
	len = fb[index].flash_max_len - len;
	flash_write(fb[index].env.data, to, len);
	FREE(fb[index].env.data);

	fb[index].dirty = 0;

	return 0;
}

/*
 * clear flash by writing all 1's value
 */
int __nvram_clear(int index)
{
	unsigned long to;
	int len;

	LIBNV_PRINT("--> __nvram_clear %d\n", index);
	LIBNV_CHECK_INDEX(-1);
	__nvram_close(index);

	//construct all 1s env block
	len = fb[index].flash_max_len - sizeof(fb[index].env.crc);
	fb[index].env.data = (char *)malloc(len);
	memset(fb[index].env.data, 0xFF, len);

	//calculate and write crc
	fb[index].env.crc = (unsigned long)crc32(0, (unsigned char *)fb[index].env.data, len);
	to = fb[index].flash_offset;
	len = sizeof(fb[index].env.crc);
	flash_write((char *)&fb[index].env.crc, to, len);

	//write all 1s data to flash
	to = to + len;
	len = fb[index].flash_max_len - len;
	flash_write(fb[index].env.data, to, len);
	FREE(fb[index].env.data);
	LIBNV_PRINT("clear flash from 0x%lx for 0x%x bytes\n", to, len);

	fb[index].valid = 0;
	fb[index].dirty = 0;
	return 0;
}

#if 0
//WARNING: this fuunction is dangerous because it erases all other data in the same sector
int nvram_erase(int index)
{
	int s, e;

	LIBNV_PRINT("--> nvram_erase %d\n", index);
	LIBNV_CHECK_INDEX(-1);
	__nvram_close(index);

	s = fb[index].flash_offset;
	e = fb[index].flash_offset + fb[index].flash_max_len - 1;
	LIBNV_PRINT("erase flash from 0x%x to 0x%x\n", s, e);
	FlashErase(s, e);
	return 0;
}
#endif

#if 1
int __getNvramNum(void)
{
	return FLASH_BLOCK_NUM+EXTEND_BLOCK_NUM;
}

size_t __getNvramOffset(int index)
{
	LIBNV_CHECK_INDEX(0);
	return fb[index].flash_offset;
}

char *__getNvramName(int index)
{
	LIBNV_CHECK_INDEX(NULL);
	return fb[index].name;
}

size_t __getNvramBlockSize(int index)
{
	LIBNV_CHECK_INDEX(0);
	return fb[index].flash_max_len;
}

unsigned int __getNvramIndex(char *name)
{
	int i;
	for (i = 0; i < FLASH_BLOCK_NUM+EXTEND_BLOCK_NUM; i++) {
		if (!strcmp(fb[i].name, name)) {
			return i;
		}
	}
	return -1;
}

void __toggleNvramDebug()
{
	if (libnvram_debug) {
		libnvram_debug = 0;
		printf("%s: turn off debugging\n", __FILE__);
	}
	else {
		libnvram_debug = 1;
		printf("%s: turn ON debugging\n", __FILE__);
	}
}
#endif


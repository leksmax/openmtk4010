#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <ctype.h>
#include <sys/ioctl.h>

#include <sys/select.h>
#include <sys/time.h>
#include <sys/wait.h>
#include "linux_socket.h"
#include "nvram_sock.h"
#include "nvram_srv_env.h"
#include "sys_debug.h"


#define DBG_SHOW_DATA_LEN	MAX_NAME_LEN

#define NVRAM_SRV_READY_SIG	SIGHUP
#define NVRAM_SRV_RUNNING	1
#define NVRAM_SRV_WAITING	2
#define NVRAM_SRV_STOPPING	3

#define SELECT_USE_TIMEOUT	0
/* SYS_Logx provide colorful debugging msg, but it runs slowly.
   Only compile SYS_Loge msg when DEBUG_SOCKET_SRV set to 0. */
#define DEBUG_SOCKET_SRV	0

#if DEBUG_SOCKET_SRV
#define LOGV(fmt, ...) 		SYS_Logv(fmt, ## __VA_ARGS__) 
#define LOGI(fmt, ...) 		SYS_Logi(fmt, ## __VA_ARGS__) 
#define LOGD(fmt, ...) 		SYS_Logd(fmt, ## __VA_ARGS__) 
#define LOGW(fmt, ...) 		SYS_Logw(fmt, ## __VA_ARGS__) 
#define LOGE(fmt, ...) 		SYS_Loge(fmt, ## __VA_ARGS__) 
#else
#define LOGV(fmt, ...)
#define LOGI(fmt, ...)
#define LOGD(fmt, ...)
#define LOGW(fmt, ...)
#define LOGE(fmt, ...) 		SYS_Loge(fmt, ## __VA_ARGS__) 
#endif

#define RALINK_NVRAM_IOCTL_GET_CMD	"nvram_get"
#define RALINK_NVRAM_IOCTL_GETALL_CMD	"ralink_init show"
#define RALINK_NVRAM_IOCTL_SET_CMD	"nvram_set"
#define RALINK_NVRAM_IOCTL_COMMIT_CMD	"nvram_commit"
#define RALINK_NVRAM_IOCTL_CLEAR_CMD	"ralink_init clear"
#define RALINK_NVRAM_CMD_NULL		"null_cmd"

/*****************************************************************/
/*              VARIABLE DECLARATION (GLOBAL & LOCAL)            */
/*****************************************************************/
struct nvram_srv_struct {
	/* keep in main while or prepare to exit 
	   1: keep in main while
	   0: prepare to exit */
	int running;

	int nvram_srv_sock;

	/* max select socket */
	int max_sock_no;

	/* agent select set */
	fd_set readfds;
} nvram_server;


/*****************************************************************/
/*                      FUNCTION PROTOTYPE                       */
/*****************************************************************/

extern void __nvram_init(int index);
extern void __nvram_close(int index);
extern int __nvram_get_flash_max_len(int index);
extern char const *__nvram_bufget(int index, char *name);
extern int __nvram_bufset(int index, char *name, char *value);
extern void __nvram_buflist(int index);
extern void __nvram_buflist_to_str(int index, char *str, int str_len);
extern int __nvram_commit(int index);
extern int __nvram_clear(int index);

int nvram_srv_sock_init(void);
void nvram_srv_sock_deinit(void);
int nvram_srv_env_init(void);
int nvram_srv_env_deinit(void);
int nvram_srv_sig_init(void);
int nvram_srv_main_loop();
static void nvram_srv_stop(int signo);
static void show_sig_info(int sig, siginfo_t *siginfo, void *context);

int nvram_get_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);
int nvram_getall_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);
int nvram_set_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);
int nvram_commit_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);
int nvram_clear_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);
int nvram_read_mac_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);

struct nvram_cmd_tbl_t{
	int msg_id;
	int (*handler)(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len);
};

static struct nvram_cmd_tbl_t nvram_cmd_tbl[] = {
	{RALINK_NVRAM_IOCTL_GET,	nvram_get_hdl},
	{RALINK_NVRAM_IOCTL_GETALL,	nvram_getall_hdl},
	{RALINK_NVRAM_IOCTL_SET,	nvram_set_hdl},
	{RALINK_NVRAM_IOCTL_COMMIT, 	nvram_commit_hdl},
	{RALINK_NVRAM_IOCTL_CLEAR, 	nvram_clear_hdl},
	{RALINK_NVRAM_IOCTL_READ_MAC, 	nvram_read_mac_hdl},
	{0xFFFFFFFF, NULL}
};

/*****************************************************************/
/*                 LOCAL FUNTION IMPLEMENTATION                  */
/*****************************************************************/
int nvram_srv_sock_init(void)
{
	struct stat st;
	if(!stat(NVRAM_SERVER_NAME, &st)){
		LOGE("nvram sock server file exist! replace it.[%s]\n", NVRAM_SERVER_NAME);
		//return -1;
	}
	nvram_server.nvram_srv_sock = socket_gram_srv_create(NVRAM_SERVER_NAME);
	nvram_server.max_sock_no = nvram_server.nvram_srv_sock;

	return 0;
}

void nvram_srv_sock_deinit(void)
{
	socket_gram_srv_close(nvram_server.nvram_srv_sock, 
						NVRAM_SERVER_NAME);
}

int nvram_srv_env_init(void)
{
//	LOGD("[%s]NVRAM_SRV_MSG_HEARDER_SIZE=%d\n", __func__, NVRAM_SRV_MSG_HEARDER_SIZE);
	__nvram_init(DEV1_NVRAM);
	__nvram_init(DEV2_NVRAM);
	__nvram_init(DEV3_NVRAM);

	nvram_server.running = NVRAM_SRV_RUNNING;

	return 0;
}

int nvram_srv_env_deinit(void)
{
	__nvram_close(DEV1_NVRAM);
	__nvram_close(DEV2_NVRAM);
	__nvram_close(DEV3_NVRAM);

	return 0;
}

int nvram_srv_sig_init(void)
{
	int i;
	struct sigaction sa;

	sa.sa_sigaction = show_sig_info;
	sa.sa_flags |= SA_SIGINFO;
	for (i = 1; i < SIGRTMAX; i++){
		if ((i != SIGKILL) && (i != SIGSTOP) && (i != 32) && (i != 33)){
			if (sigaction(i, &sa, NULL) < 0) {
				fprintf(stderr, "sigaction(%d, &sa, NULL) NG\n", i);
				perror("nvram_srv_env_init.sigaction");
			}
		}
	}

	return 0;
}

static void show_sig_info(int sig, siginfo_t *siginfo, void *context)
{
	FILE *fd = fopen("/tmp/nvramd_info", "a");
	pid_t sender_pid = siginfo->si_pid;

	if (!fd){
		fprintf(stderr, "fopen /tmp/nvram_info NG\n");
		perror("show_sig_info");
	}

	fprintf(fd, "[nvramd] rec sig=%d from sender_pid=%d\n", sig, sender_pid);
	fclose(fd);

	if (sig == SIGTERM)
		nvram_srv_stop(sig);

	return;
}

static void nvram_srv_stop(int signo)
{
	fprintf(stderr, "[%s][%d] <------ \n", __FUNCTION__, getpid());
	LOGE("[%s][%d] <------ \n", __FUNCTION__, getpid());
	nvram_server.running = NVRAM_SRV_STOPPING;
}

#if DEBUG_SOCKET_SRV
static int nvram_srv_buf_tracking(int sock)
{
	int size;
	int bytes_unsent;
	int io_size;
	int io_pkt;
	int rcv_buf = 0;
	socklen_t buf_size;

	//sleep(2);

	ioctl(sock, FIONREAD, &size);
	ioctl(sock, TIOCOUTQ, &bytes_unsent);
	ioctl(sock, FIOQSIZE, &io_size);
	ioctl(sock, TIOCPKT, &io_pkt);
	buf_size = sizeof(rcv_buf);
	getsockopt(sock, SOL_SOCKET, SO_RCVBUF, &rcv_buf, &buf_size);

	LOGD("FIONREAD = %d, TIOCOUTQ = %d, FIOQSIZE = %d, TIOCPKT = %d, SO_RCVBUF = %d\n",
			size, bytes_unsent, io_size, io_pkt, rcv_buf);

	return 0;
}

char *nvram_srv_msg_parser(uint32_t msg_id)
{
	char *msg_str;

	switch (msg_id)
	{
		case RALINK_NVRAM_IOCTL_GET:
			msg_str = RALINK_NVRAM_IOCTL_GET_CMD;
			break;
		case RALINK_NVRAM_IOCTL_GETALL:
			msg_str = RALINK_NVRAM_IOCTL_GETALL_CMD;
			break;
		case RALINK_NVRAM_IOCTL_SET:
			msg_str = RALINK_NVRAM_IOCTL_SET_CMD;
			break;
		case RALINK_NVRAM_IOCTL_COMMIT:
			msg_str = RALINK_NVRAM_IOCTL_COMMIT_CMD;
			break;
		case RALINK_NVRAM_IOCTL_CLEAR:
			msg_str = RALINK_NVRAM_IOCTL_CLEAR_CMD;
			break;
		default:
			msg_str = RALINK_NVRAM_CMD_NULL;
			break;
	}

	return msg_str;
}
#endif

int nvram_srv_recvfrom(int sock, char *buf, ssize_t len, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
#if DEBUG_SOCKET_SRV
	ssize_t  ret;
	int i, ret_d;
	struct nvram_srv_msg *nmsg;
	uint8_t *data;

	nvram_srv_buf_tracking(sock);

	ret = socket_gram_srv_recvfrom(sock, buf, len, cli_addr, sock_len);
	if (ret > 0)
	{
		nmsg = (struct nvram_srv_msg *)buf;
		data = (uint8_t *)nmsg->name;

		LOGD("<nvramd  rcv(%d)> : msg = %s, len = %d, data =\n", sock, nvram_srv_msg_parser(nmsg->msg_id), ret);
		ret_d = (int)ret - 4;
		for (i = 0; (i < ret_d) && (i < DBG_SHOW_DATA_LEN); i++)
		{
			LOGI(" %.2X", data[i]);
			if (!(i & (8 - 1)))
				LOGI("\n");
		}
	}
	LOGI("\n");

	return ret;
#else
	return socket_gram_srv_recvfrom(sock, buf, len, cli_addr, sock_len);
#endif
}

int nvram_read_mac_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
	LOGD("nvram_get %s %s\n", __getNvramName(nmsg->index), nmsg->name);
	flash_read_mac(nmsg->value);
	snprintf(nmsg->value, sizeof(nmsg->value), "%s", nmsg->value);
	LOGD("[%s]nmsg->value=%s\n", __func__, nmsg->value);

	if(socket_gram_srv_sendto(nvram_srv->nvram_srv_sock, (char *)nmsg, sizeof(struct nvram_srv_msg), (struct sockaddr *)cli_addr, *sock_len) != sizeof(struct nvram_srv_msg))
		LOGE("Sock [%d] sending datagram packet fail!\n", nvram_srv->nvram_srv_sock);

	return 0;
}

int nvram_get_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
	size_t send_len;

	LOGD("nvram_get %s %s\n", __getNvramName(nmsg->index), nmsg->name);
	send_len = snprintf(nmsg->name, sizeof(nmsg->name), "%s", __nvram_bufget(nmsg->index, nmsg->name));
	LOGD("[%s]nmsg->value=%s\n", __func__, nmsg->value);

	nmsg->data_len = send_len + 1;
	send_len += NVRAM_SRV_MSG_HEADER_SIZE;

	if(socket_gram_srv_sendto(nvram_srv->nvram_srv_sock, (char *)nmsg, send_len, (struct sockaddr *)cli_addr, *sock_len) !=  send_len)
		LOGE("Sock [%d] sending datagram packet fail!\n", nvram_srv->nvram_srv_sock);
	return 0;
}

int nvram_getall_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
	ssize_t ret; 
	size_t len;
	char *buf;
	uint32_t buflen = __nvram_get_flash_max_len(nmsg->index);

	if(buflen == 0)
		return 0;

	buf = malloc(sizeof(char) * buflen);
	if(!buf){
		LOGE("malloc error\n");
	}
	memset(buf, 0, buflen);

	LOGD("ralink_init show %s buflen=%u\n", __getNvramName(nmsg->index), buflen);
	__nvram_buflist_to_str(nmsg->index, buf, buflen);
	LOGD("%s\n", buf);

	nmsg->data_len = buflen;

	len = NVRAM_SRV_MSG_HEADER_SIZE;
	ret = socket_gram_srv_sendto(nvram_srv->nvram_srv_sock, (char *)nmsg, len,
				(struct sockaddr *)cli_addr, *sock_len);
	if(ret != len)
		LOGE("Sock[%d] sending %dbytes datagram packet fail[%d]!\n", 
				len, nvram_srv->nvram_srv_sock, ret);

	ret = socket_gram_srv_sendto(nvram_srv->nvram_srv_sock, buf, buflen,
				(struct sockaddr *)cli_addr, *sock_len);
	if(ret != buflen){
		LOGE("Sock[%d] sending %dbytes datagram packet fail[%d]!\n",
				buflen, nvram_srv->nvram_srv_sock, ret);
	}

	free(buf);

	return 0;
}

int nvram_set_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
	LOGD("nvram_set %s %s %s\n", __getNvramName(nmsg->index), nmsg->name, nmsg->value);
	return __nvram_bufset(nmsg->index, nmsg->name, nmsg->value);
}

int nvram_commit_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
	LOGD("nvram_commit %s\n", __getNvramName(nmsg->index));
	return __nvram_commit(nmsg->index);
}

int nvram_clear_hdl(struct nvram_srv_struct *nvram_srv, struct nvram_srv_msg *nmsg, struct sockaddr_un *cli_addr, socklen_t *sock_len)
{
	LOGD("nvram_clear %s\n", __getNvramName(nmsg->index));
	__nvram_clear(nmsg->index);

	return 0;
}

int nvram_srv_handler(struct nvram_srv_struct *nvram_srv)
{
	struct nvram_srv_msg nmsg;
	struct nvram_cmd_tbl_t *nvram_handlers;
	struct sockaddr_un cli_addr;
	socklen_t sock_len;
	int i, hdl_found;

	sock_len = sizeof(struct sockaddr_un);

	nvram_srv_recvfrom(nvram_srv->nvram_srv_sock, (char *)&nmsg, sizeof(struct nvram_srv_msg), &cli_addr, &sock_len);

	for (i=0;;i++){
		nvram_handlers = &nvram_cmd_tbl[i];

		if (nvram_handlers->msg_id == nmsg.msg_id){
			hdl_found = 1;
			break;
		}

		if (nvram_handlers->handler == NULL){
			hdl_found = 0;
			break;
		}
	}

	if (!hdl_found){
		LOGE("[%s] msg command can not be found.\n", __func__);
	}

	nvram_handlers->handler(nvram_srv, &nmsg, &cli_addr, &sock_len);

	return 0;
}

int nvram_srv_main_loop()
{
	fd_set infds;
	int ret;
	struct nvram_srv_struct *nvram_srv = &nvram_server;

	/* register rplayer cmder server sock to select */
	FD_SET(nvram_srv->nvram_srv_sock, &(nvram_srv->readfds));

	while (nvram_srv->running != NVRAM_SRV_STOPPING){

		infds = nvram_srv->readfds;
#if SELECT_USE_TIMEOUT
		struct timeval tv;
		/* set select timeout */
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		ret = select((nvram_srv->max_sock_no + 1), &infds, (fd_set *)NULL, (fd_set *)NULL, &tv);
		if(ret == 0){ // timeout expired for exit checking or interrupted 
			LOGV("[%s][%u]select timeout. Continue. nvram_srv->running=%d\n", __FUNCTION__, __LINE__, nvram_srv->running);
			continue;
		}
#else
		ret = select((nvram_srv->max_sock_no + 1), &infds, (fd_set *)NULL, (fd_set *)NULL, (struct timeval *)0);
#endif
		if(ret < 0){
			perror("\n[nvram_srv_main_loop] select");
			continue;
		}

		//LOGV("select out, infds[0] = %x\n", __FDS_BITS(&infds)[0]);

		if (FD_ISSET(nvram_srv->nvram_srv_sock, &infds)){
			ret = nvram_srv_handler(nvram_srv);
			if (ret < 0) {
				FD_CLR(nvram_srv->nvram_srv_sock, &(nvram_srv->readfds));
				perror("\n [nvram_srv_handler]");
			}	
		}

	}

	LOGE("[%s][%u]exit main loop.\n", __FUNCTION__, __LINE__);

	return 0;
}

int main(int argc, char *argv[])
{

	nvram_srv_sock_init();
	nvram_srv_env_init();

	daemon(0, 1);
	nvram_srv_sig_init();
	nvram_srv_main_loop();

	nvram_srv_env_deinit();
	nvram_srv_sock_deinit();

	return 0;
}

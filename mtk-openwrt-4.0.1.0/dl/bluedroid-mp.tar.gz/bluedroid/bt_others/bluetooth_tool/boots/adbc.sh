wget "http://mirrors.neusoft.edu.cn/android/repository/platform-tools_r23.0.1-linux.zip"
unzip platform-tools_r23.0.1-linux.zip

#ifndef __BTUT_HID_IF_H__
#define __BTUT_HID_IF_H__

#define CMD_KEY_HID        "HID"

int btut_hid_init();
int btut_hid_deinit();

#endif /* __BTUT_HID_IF_H__ */

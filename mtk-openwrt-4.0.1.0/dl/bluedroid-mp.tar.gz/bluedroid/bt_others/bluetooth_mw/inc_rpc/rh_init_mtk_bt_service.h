#ifndef _RH_INIT_MTK_BT_SERVICE_H_
#define _RH_INIT_MTK_BT_SERVICE_H_

#include "ri_common.h"

extern RPC_ID_T c_rpc_start_mtk_bt_service_server(VOID);
extern INT32 c_rpc_init_mtk_bt_service_server(VOID);

#endif

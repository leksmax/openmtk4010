#ifndef __BTMW_RPC_TEST_HFCLIENT_IF_H__
#define __BTMW_RPC_TEST_HFCLIENT_IF_H__

#define BTMW_RPC_TEST_CMD_KEY_HFCLIENT   "MW_RPC_HFCLIENT"

int btmw_rpc_test_hfclient_init();
int btmw_rpc_test_hfclient_deinit();

#endif /* __BTMW_RPC_TEST_HFCLIENT_IF_H__ */

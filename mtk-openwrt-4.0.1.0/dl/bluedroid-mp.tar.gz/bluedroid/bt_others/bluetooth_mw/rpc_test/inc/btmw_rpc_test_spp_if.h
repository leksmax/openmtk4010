#ifndef __BTMW_RPC_TEST_SPP_IF_H__
#define __BTMW_RPC_TEST_SPP_IF_H__

#define BTMW_RPC_TEST_CMD_KEY_SPP     "MW_RPC_SPP"

int btmw_rpc_test_spp_init();

#endif /* __BTMW_RPC_TEST_SPP_IF_H__ */

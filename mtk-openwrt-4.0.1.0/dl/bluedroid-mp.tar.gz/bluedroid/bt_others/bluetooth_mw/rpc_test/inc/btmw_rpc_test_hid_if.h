#ifndef __BTMW_RPC_TEST_HID_IF_H__
#define __BTMW_RPC_TEST_HID_IF_H__

#define BTMW_RPC_TEST_CMD_KEY_HID        "MW_RPC_HID"

int btmw_rpc_test_hid_init();
int btmw_rpc_test_hid_deinit();

#endif /* __BTMW_RPC_TEST_HID_IF_H__ */

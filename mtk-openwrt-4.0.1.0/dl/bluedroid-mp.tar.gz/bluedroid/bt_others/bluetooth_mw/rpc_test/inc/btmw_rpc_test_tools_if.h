#ifndef __BTMW_RPC_TEST_TOOLS_IF_H__
#define __BTMW_RPC_TEST_TOOLS_IF_H__

#define BTMW_RPC_TEST_CMD_KEY_TOOLS     "MW_TOOLS"

int btmw_rpc_test_tools_init();

#endif /* __BTMW_RPC_TEST_TOOLS_IF_H__ */

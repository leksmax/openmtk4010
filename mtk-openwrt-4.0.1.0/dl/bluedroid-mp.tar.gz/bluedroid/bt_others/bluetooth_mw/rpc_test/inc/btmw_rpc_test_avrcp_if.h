#ifndef __BTMW_RPC_TEST_AVRCP_IF_H__
#define __BTMW_RPC_TEST_AVRCP_IF_H__

#include "btmw_rpc_test_cli.h"
#include "btmw_rpc_test_debug.h"

#define BTMW_RPC_TEST_CMD_KEY_AVRCP_CT     "MW_RPC_AVRCP_CT"

int btmw_rpc_test_rc_init(void);
int btmw_rpc_test_rc_deinit(void);

#endif /* __BTUT_AVRCP_IF_H__ */

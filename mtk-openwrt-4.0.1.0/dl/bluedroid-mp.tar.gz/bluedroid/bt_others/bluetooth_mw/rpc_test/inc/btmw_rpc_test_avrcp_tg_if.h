#ifndef __BTMW_RPC_TEST_AVRCP_TG_IF_H__
#define __BTMW_RPC_TEST_AVRCP_TG_IF_H__


#include "btmw_rpc_test_cli.h"
#include "btmw_rpc_test_debug.h"

#define BTMW_RPC_TEST_CMD_KEY_AVRCP_TG     "MW_RPC_AVRCP_TG"
#define AVRCP_CT_MAX_ATTR_NO 7

int btmw_rpc_test_rc_tg_init(void);
int btmw_rpc_test_rc_tg_deinit(void);

#endif /* __BTMW_RPC_TEST_AVRCP_IF_H__ */

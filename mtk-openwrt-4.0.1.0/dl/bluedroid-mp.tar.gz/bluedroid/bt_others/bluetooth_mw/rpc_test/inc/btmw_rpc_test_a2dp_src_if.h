#ifndef __BTMW_RPC_TEST_A2DP_SRC_IF_H__
#define __BTMW_RPC_TEST_A2DP_SRC_IF_H__

#include "u_common_rpcipc.h"
#include "u_bluetooth.h"

INT32 btmw_rpc_test_a2dp_src_init(VOID);

#endif /* __BTMW_RPC_TEST_A2DP_SRC_IF_H__ */

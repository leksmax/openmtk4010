#ifndef __BTMW_RPC_TEST_GATTS_IF_H__
#define __BTMW_RPC_TEST_GATTS_IF_H__

#define BTMW_RPC_TEST_CMD_KEY_GATTS      "MW_RPC_GATTS"
#define BTMW_RPC_TEST_GATTS_SERVER_UUID  "49557E51-D815-11E4-8830-0800200C9A66"

int btmw_rpc_test_gatts_init();
int btmw_rpc_test_gatts_deinit();


#endif /* __BTMW_RPC_TEST_GATTS_IF_H__ */

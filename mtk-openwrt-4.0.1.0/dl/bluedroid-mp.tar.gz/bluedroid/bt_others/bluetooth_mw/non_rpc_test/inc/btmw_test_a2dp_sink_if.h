#ifndef __BTMW_TEST_A2DP_SINK_IF_H__
#define __BTMW_TEST_A2DP_SINK_IF_H__

INT32 btmw_test_a2dp_sink_init(VOID);

#endif /* __BTMW_TEST_A2DP_SINK_IF_H__ */

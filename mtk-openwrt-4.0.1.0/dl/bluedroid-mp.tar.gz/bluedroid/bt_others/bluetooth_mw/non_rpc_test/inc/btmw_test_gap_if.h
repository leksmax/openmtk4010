#ifndef __BTMW_TEST_GAP_IF_H__
#define __BTMW_TEST_GAP_IF_H__

#define BTMW_TEST_CMD_KEY_GAP     "MW_GAP"

int btmw_test_gap_init();

#endif /* __BTMW_TEST_GAP_IF_H__ */

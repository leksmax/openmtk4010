#ifndef __BTMW_TEST_HID_IF_H__
#define __BTMW_TEST_HID_IF_H__

#define BTMW_TEST_CMD_KEY_HID        "MW_HID"

int btmw_test_hid_init();
int btmw_test_hid_deinit();

#endif /* __BTMW_TEST_HID_IF_H__ */

#ifndef __BTMW_TEST_GATT_APCLI_REF_H__
#define __BTMW_TEST_GATT_APCLI_REF_H__
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "bluetooth.h"
#include "bt_gatt.h"
#include "bt_gatt_server.h"

#include "btmw_test_debug.h"
#include "btmw_test_gatt_if.h"
#include "btmw_test_gatts_if.h"
#include "btmw_test_config.h"

#include "bt_mw_common.h"
#include "u_bt_mw_types.h"
#include "c_bt_mw_gatt.h"
#include "u_bt_mw_common.h"
#include "u_bt_mw_gatt.h"

#if CONFIG_USER_GATT_APCLI

/* Configuration Data -------------------------- */
/* TODO: currently this simple app profile only support 1 primaray service
   in a gatt server of app profile at a time. */

/* APP_DESC_MAX_NUM decide the max number of descriptor in one
   characteristics structure */
#define APP_DESC_MAX_NUM	6
/* APP_CHAR_MAX_NUM decide the max support number of characteristics
   of this app */
#define APP_CHAR_MAX_NUM	12
#define APP_UUID_MAX_LEN	BT_GATT_MAX_UUID_LEN
#define APP_DESC_LEN_MAX	64


#define GATT_ENABLED		1
#define GATT_DISABLED		0

/* APP gatt structure definition */
struct app_client_data {
	INT32 client_if;
	CHAR  uuid[APP_UUID_MAX_LEN];
	INT32 min_interval;
	INT32 max_interval;
	INT32 adv_type;
	INT32 chnl_map;
	INT32 tx_power;
	INT32 timeout;
	UINT8 set_scan_rsp;
	UINT8 include_name;
	UINT8 incl_txpower;
	INT32 appearance;
	INT32 manufacturer_len;
	CHAR* manufacturer_data;
	INT32 service_data_len;
	CHAR* service_data;
	INT32 service_uuid_len;
	CHAR* service_uuid;
};

struct app_server_data {
	INT32 server_if;
	INT32 conn_id;
	CHAR  uuid[APP_UUID_MAX_LEN];
};

struct app_service_data {
	INT32 handle;
	CHAR  uuid[APP_UUID_MAX_LEN];
	INT32 handle_num;
	UINT8 is_primary; //0 or 1
};

struct app_char_data;

struct app_desc_data {
	INT32 status;
	INT32 handle;
	CHAR  uuid[APP_UUID_MAX_LEN];
	INT32 permission;
	INT32 max_len;
	CHAR  value[APP_DESC_LEN_MAX];
	struct app_char_data *char_p;
};

struct app_char_action {
	CHAR* (*read)(struct app_char_data* char_data, INT32 offset);
	CHAR* (*write)(struct app_char_data* char_data, INT32 offset, CHAR* value, INT32 len);
	VOID (*connect)(struct app_char_data* char_data);
	VOID (*disconnect)(struct app_char_data* char_data);
};

struct app_char_data {
	UINT8 status;
	INT32 handle;
	CHAR  uuid[APP_UUID_MAX_LEN];
	INT32 property;
	INT32 permission;
	INT32 max_len;
	CHAR  *value;
	INT32 desc_num;
	struct app_desc_data desc[APP_DESC_MAX_NUM];
	struct app_char_action action;
	struct app_service_data *service_p;
};

struct app_gatt_profile_data {
	struct app_client_data  client;
	struct app_server_data	server;
	struct app_service_data	service;
	struct app_char_data	chars[APP_CHAR_MAX_NUM];
	INT32  			char_num;
	CHAR *			dev_name;
};

/* APP hook function declaration for btmw gatt */
INT32 btmw_apcli_gatts_register_server(INT32 argc, CHAR **argv);
INT32 btmw_gatts_app_init();
INT32 btmw_gattc_app_init();
VOID btmw_gatts_app_notify(struct app_char_data* char_data, CHAR* value, INT32 len);

/* APP callback function declaration for btmw gatt */
VOID btmw_gatts_app_event_cbk(BT_GATTS_EVENT_T bt_gatts_event);
VOID btmw_gatts_app_reg_server_cbk(BT_GATTS_REG_SERVER_RST_T *bt_gatts_reg_server);
VOID btmw_gatts_app_add_srvc_cbk(BT_GATTS_ADD_SRVC_RST_T *bt_gatts_add_srvc);
VOID btmw_gatts_app_add_char_cbk(BT_GATTS_ADD_CHAR_RST_T *bt_gatts_add_char);
VOID btmw_gatts_app_add_desc_cbk(BT_GATTS_ADD_DESCR_RST_T *bt_gatts_add_desc);
VOID btmw_gatts_app_req_read_cbk(BT_GATTS_REQ_READ_RST_T *bt_gatts_read);
VOID btmw_gatts_app_req_write_cbk(BT_GATTS_REQ_WRITE_RST_T *bt_gatts_write);
#endif
#endif

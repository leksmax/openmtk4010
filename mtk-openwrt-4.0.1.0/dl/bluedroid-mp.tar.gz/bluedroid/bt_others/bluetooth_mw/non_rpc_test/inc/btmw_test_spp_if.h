#ifndef __BTMW_TEST_SPP_IF_H__
#define __BTMW_TEST_SPP_IF_H__

#define BTMW_TEST_CMD_KEY_SPP        "MW_SPP"

int btmw_test_spp_init();
int btmw_test_spp_deinit();

#endif /* __BTMW_TEST_SPP_IF_H__ */

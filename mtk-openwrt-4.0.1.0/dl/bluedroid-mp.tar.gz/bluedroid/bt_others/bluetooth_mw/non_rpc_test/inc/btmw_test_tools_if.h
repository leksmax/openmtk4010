#ifndef __BTMW_TEST_TOOLS_IF_H__
#define __BTMW_TEST_TOOLS_IF_H__

#define BTMW_TEST_CMD_KEY_TOOLS     "MW_TOOLS"

int btmw_test_tools_init();

#endif /* __BTMW_TEST_TOOLS_IF_H__ */

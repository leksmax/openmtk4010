#ifndef __BTMW_TEST_A2DP_SRC_IF_H__
#define __BTMW_TEST_A2DP_SRC_IF_H__

INT32 btmw_test_a2dp_src_init(VOID);

#endif /* __BTMW_TEST_A2DP_SRC_IF_H__ */

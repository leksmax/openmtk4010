/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <unistd.h>
//#include "x_common.h"
#include "x_kmem.h"
//#include "x_assert.h"
//#include "os_linux.h"

#define IOCTL_OSAI_CREATE_BDPPOOL_MEM   _IOWR('o', 10, int)
#define IOCTL_OSAI_GET_BDPPOOL_HANDLE   _IOR('o', 11, int)
#define IOCTL_OSAI_GET_BDPPOOL_HANDLE_SIZE  _IOR('o', 12, int)
#define IOCTL_OSAI_FREE_BDPPOOL_MEM     _IOW('o', 13, int)

#define PAGE_SIZE       4096
#define PAGE_MASK       (~(PAGE_SIZE - 1))
#define PTR_SIZE 64

#define UPG_NAME "UPG_PROG"

#if CONFIG_USE_TMPFS_TO_ALLOC_MEM
#define TMPFS_UPG_NAME "/dev/shm/UPG_PROG"
#endif

static int fd_osai = 0;

VOID *x_mem_alloc_large(UINT32 z_size)
{
  UINT32 *h_ptr;
  INT32 ret, fd;

  fd = shm_open(UPG_NAME, O_RDWR | O_CREAT, 0600);

  if (fd == -1)
  {
      return NULL;
  }

  h_ptr = (UINT32 *)mmap(NULL, PTR_SIZE * sizeof(UINT32), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
  close(fd);
  if (h_ptr == MAP_FAILED)
  {
    return NULL;
  }

  z_size = (z_size + ~PAGE_MASK) & PAGE_MASK;

  if (fd_osai == 0)
  {
    fd_osai = open("/dev/osai", O_RDWR);
    if (fd_osai == -1)
    {
      return NULL;
    }
  }

  ret = ioctl(fd_osai, IOCTL_OSAI_CREATE_BDPPOOL_MEM, z_size);
  //ASSERT(ret == 0);
  if (ret != 0)
    return NULL;

  ret = ioctl(fd_osai, IOCTL_OSAI_GET_BDPPOOL_HANDLE, &h_ptr[1]);
  //ASSERT(ret == 0);
  if (ret != 0)
    return NULL;

  ret = ioctl(fd_osai, IOCTL_OSAI_GET_BDPPOOL_HANDLE_SIZE, h_ptr);
  //ASSERT(ret == 0);
  if (ret != 0)
    return NULL;

  if (h_ptr[0] == 1)
    return x_kmem_block_map(h_ptr[1]);

  return x_kmem_block_multimap(h_ptr[0], &h_ptr[1]);
}

#if CONFIG_USE_TMPFS_TO_ALLOC_MEM
VOID *x_mem_alloc_large_with_tmpfs(UINT32 z_size)
{
  UINT32 *h_ptr;
  INT32 ret, fd;

  fd = open(TMPFS_UPG_NAME, O_RDWR | O_CREAT, 0666);

  if (fd == -1)
  {
      return NULL;
  }

  h_ptr = (UINT32 *)mmap(NULL, PTR_SIZE * sizeof(UINT32), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
  close(fd);
  if (h_ptr == MAP_FAILED)
  {
    return NULL;
  }

  z_size = (z_size + ~PAGE_MASK) & PAGE_MASK;

  if (fd_osai == 0)
  {
    fd_osai = open("/dev/osai", O_RDWR);
    if (fd_osai == -1)
    {
      return NULL;
    }
  }

  ret = ioctl(fd_osai, IOCTL_OSAI_CREATE_BDPPOOL_MEM, z_size);
  //ASSERT(ret == 0);
  if (ret != 0)
    return NULL;

  ret = ioctl(fd_osai, IOCTL_OSAI_GET_BDPPOOL_HANDLE, &h_ptr[1]);
  //ASSERT(ret == 0);
  if (ret != 0)
    return NULL;

  ret = ioctl(fd_osai, IOCTL_OSAI_GET_BDPPOOL_HANDLE_SIZE, h_ptr);
  //ASSERT(ret == 0);
  if (ret != 0)
    return NULL;

  if (h_ptr[0] == 1)
    return x_kmem_block_map(h_ptr[1]);

  return x_kmem_block_multimap(h_ptr[0], &h_ptr[1]);
}
#endif

VOID *x_mem_get_alloc_large(void)
{
  UINT32 *h_ptr;
  INT32 fd;

  fd = shm_open(UPG_NAME, O_RDWR, 0600);

  if (fd == -1)
  {
      return NULL;
  }
  h_ptr = (UINT32 *)mmap(NULL, PTR_SIZE * sizeof(UINT32), PROT_READ, MAP_SHARED, fd, 0);
  close(fd);
  if (h_ptr == MAP_FAILED)
  {
    return NULL;
  }

  if (h_ptr[0] == 1)
    return x_kmem_block_map(h_ptr[1]);

  return x_kmem_block_multimap(h_ptr[0], &h_ptr[1]);
}

#if CONFIG_USE_TMPFS_TO_ALLOC_MEM
VOID *x_mem_get_alloc_large_with_tmpfs(void)
{
  UINT32 *h_ptr;
  INT32 fd;

  fd = open(TMPFS_UPG_NAME, O_RDWR);

  if (fd == -1)
  {
      return NULL;
  }
  h_ptr = (UINT32 *)mmap(NULL, PTR_SIZE * sizeof(UINT32), PROT_READ, MAP_SHARED, fd, 0);
  close(fd);
  if (h_ptr == MAP_FAILED)
  {
    return NULL;
  }

  if (h_ptr[0] == 1)
    return x_kmem_block_map(h_ptr[1]);

  return x_kmem_block_multimap(h_ptr[0], &h_ptr[1]);
}
#endif

VOID x_mem_free_alloc_large(void *ptr)
{
  INT32 ret;

  x_kmem_block_unmap(ptr);

  ret = ioctl(fd_osai, IOCTL_OSAI_FREE_BDPPOOL_MEM, 0);
  //ASSERT(ret == 0);
  if (ret != 0)
    return;
  close(fd_osai);
  fd_osai = 0;
}

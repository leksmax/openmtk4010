#include <stdio.h>
#include "rpc.h"
#include "ri_common.h"

#define RET_ON_FAIL(stmt) \
do {\
    INT32 __i4_ret;\
    __i4_ret = (stmt);\
    if(__i4_ret != RPCR_OK)\
    {   RPC_ERROR("RPC Failure %s, #%d\n", __FUNCTION__, __LINE__);\
        return __i4_ret;\
    }\
}while(0)
#if 0
static INT32    i4_seria = 0;

static INT32 _thread_create(
    os_main_fct  pf_main,
    SIZE_T       z_stack_size,
    UINT8        ui1_priority,
    SIZE_T       z_arg_size,
    VOID*        pv_arg)
{
    HANDLE_T        h_th;
    CHAR            ps_name[17];

    x_sprintf(ps_name, "RPC_%d", (int)(i4_seria));

    if(x_thread_create(
                &h_th,
                ps_name,
                z_stack_size,
                ui1_priority,
                pf_main,
                z_arg_size,
                pv_arg) != OSR_OK)
    {
        return RPCR_OSERR;
    }

    printf("RPC_%d is created\n", (int)i4_seria++);

    return RPCR_OK;

}
#endif

/*static BOOL _wrapper_free_cb (HANDLE_T       h_handle,
                         HANDLE_TYPE_T  e_type,
                         VOID*          pv_obj,
                         VOID*          pv_tag,
                         BOOL           b_req_handle)
{
    RPC_CB_NFY_TAG_T * pt_nfy_tag;
    BOOL b_return;

    pt_nfy_tag = (RPC_CB_NFY_TAG_T *) pv_obj;

    if (pt_nfy_tag->pf_old_free (h_handle,
                                 e_type,
                                 pt_nfy_tag->pv_old_pvt,
                                 pv_tag,
                                 b_req_handle))
    {
        ri_free_cb_tag (pt_nfy_tag);
        b_return = TRUE;
    }
    else
    {
        ri_free_cb_tag (pt_nfy_tag);
        b_return = FALSE;
    }

    return (b_return);
}*/

EXPORT_SYMBOL RPC_CB_NFY_TAG_T * ri_create_cb_tag(
    RPC_ID_T t_rpc_id,
    VOID *   apv_cb_addr_ex[],
    SIZE_T   z_num,
    VOID *   pv_tag)
{
    RPC_CB_NFY_TAG_T *   pt_nfy_tag;

    pt_nfy_tag = (RPC_CB_NFY_TAG_T *)malloc(sizeof(RPC_CB_NFY_TAG_T));
    if(pt_nfy_tag == NULL)
    {
        printf("<Server>alloc memory for tag error\n");

        return NULL;
    }
    else
    {
        printf("<Server>alloc memory for tag succeed: 0x%lx\n", (INT32)pt_nfy_tag);
    }

    pt_nfy_tag->t_id        = t_rpc_id;
    pt_nfy_tag->pv_tag      = pv_tag;

    if(z_num == 1)
    {
        pt_nfy_tag->pv_cb_addr  = apv_cb_addr_ex[0];
    }
    else if(z_num == 0)
    {
        //do nothing
    }
    else
    {
        SIZE_T z_i;
        for(z_i = 0; z_i < z_num; z_i ++)
        {
            pt_nfy_tag->apv_cb_addr_ex[z_i] = apv_cb_addr_ex[z_i];
        }
    }

    return pt_nfy_tag;
}


EXT_RPC_CB_NFY_TAG_T * ri_create_ext_cb_tag(
    RPC_ID_T t_rpc_id,
    VOID *   apv_cb_addr_ex[],
    SIZE_T   z_num,
    VOID *   pv_tag,
    UINT32    ui4_pb_handle)
{
    EXT_RPC_CB_NFY_TAG_T *   pt_nfy_tag;

    pt_nfy_tag = (EXT_RPC_CB_NFY_TAG_T *)malloc(sizeof(EXT_RPC_CB_NFY_TAG_T));
    if(pt_nfy_tag == NULL)
    {
        printf("<Server>alloc memory for tag error\n");

        return NULL;
    }
    else
    {
        printf("<Server>alloc memory for tag succeed: 0x%lx\n", (INT32)pt_nfy_tag);
    }

    pt_nfy_tag->t_id        = t_rpc_id;
    pt_nfy_tag->pv_tag      = pv_tag;
    pt_nfy_tag->ui4_pb_handle        = ui4_pb_handle;

    if(z_num == 1)
    {
        pt_nfy_tag->pv_cb_addr  = apv_cb_addr_ex[0];
    }
    else if(z_num == 0)
    {
        //do nothing
    }
    else
    {
        SIZE_T z_i;
        for(z_i = 0; z_i < z_num; z_i ++)
        {
            pt_nfy_tag->apv_cb_addr_ex[z_i] = apv_cb_addr_ex[z_i];
        }
    }

    return pt_nfy_tag;
}


EXPORT_SYMBOL VOID ri_free_cb_tag(RPC_CB_NFY_TAG_T *   pt_nfy_tag)
{
    free(pt_nfy_tag);
}


VOID ri_free_ext_cb_tag(EXT_RPC_CB_NFY_TAG_T *   pt_ext_nfy_tag)
{
    free(pt_ext_nfy_tag);
}

/*VOID ri_bind_cb_tag(HANDLE_T h_obj, RPC_CB_NFY_TAG_T * pt_nfy_tag)
{
    if(pt_nfy_tag != NULL)
    {
        handle_set_free_fct(h_obj,
                        pt_nfy_tag,
                        _wrapper_free_cb,
                        &pt_nfy_tag->pv_old_pvt,
                        &pt_nfy_tag->pf_old_free);
    }
}*/

EXPORT_SYMBOL INT32 c_rpc_server_init(VOID)
{
    printf("c_rpc_server_init is called\n");

    //OS_FNCT_T t_of = {_thread_create};

    rpc_init(NULL);

    return RPCR_OK;
}


RPC_ID_T c_rpc_start_server(VOID)
{
    printf("YZ c_rpc_start_server is called\n");

    return rpc_open_server("mtkpbctrl"" "RPC_KW_LOG_FUNCTION" "RPC_KW_LOG_LEVEL, rpcu_default_output_log, 15);
    //return rpc_open_server("mtkpbctrl");
}

RPC_ID_T c_rpc_start_snd_server(VOID)
{
    printf("c_rpc_start_snd_server is called\n");

    return rpc_open_server("mtkpbsnd");
}

RPC_ID_T c_rpc_start_misc_server(VOID)
{
    printf("c_rpc_start_misc_server is called\n");

    return rpc_open_server("mtkpbmisc");
}



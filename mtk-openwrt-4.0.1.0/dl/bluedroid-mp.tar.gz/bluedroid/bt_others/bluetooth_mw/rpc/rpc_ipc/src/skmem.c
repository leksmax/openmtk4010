/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/


#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#ifdef _BDPPROG
#include "x_assert.h"
#else
#include <assert.h>
#define ASSERT(X) assert((X))
#define VERIFY(X) ((X) ? (void)(0) : assert(0 && #X))
#endif

#include "x_smem.h"
#include "x_kmem.h"


struct list_head {
	struct list_head *next, *prev;
};

static inline void __list_add(struct list_head *new,
			      struct list_head *prev,
			      struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

static inline void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

static inline void __list_del(struct list_head * prev, struct list_head * next)
{
	next->prev = prev;
	prev->next = next;
}

static inline void list_del(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_for_each_entry(pos, head, member) \
	for (pos = list_entry((head)->next, typeof(*pos), member); &pos->member != (head); pos = list_entry(pos->member.next, typeof(*pos), member))

typedef struct _SMEM_MAP
{
    struct list_head list;
    int fd;
    void *addr;
    size_t size;
} SMEM_MAP, *PSMEM_MAP;

static struct list_head smem_list = { &smem_list, &smem_list };
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

#define HANDLE_NAME_LENGTH 15
#define HANDLE_TO_NAME(name, handle) snprintf((name), HANDLE_NAME_LENGTH, "/smem-%08x", (unsigned int)(handle))
#define SMEM_HANDLE_MIN 0x40000000
#define SMEM_HANDLE_MAX 0x80000000
static HANDLE_T smem_handle = SMEM_HANDLE_MIN;

HANDLE_T x_smem_block_alloc(SIZE_T z_size)
{
    char name[HANDLE_NAME_LENGTH];
    HANDLE_T handle;
    int fd;

    while (TRUE)
    {
        handle = smem_handle;
        smem_handle = smem_handle + 1 < SMEM_HANDLE_MAX ? smem_handle + 1 : SMEM_HANDLE_MIN;
        HANDLE_TO_NAME(name, handle);
        fd = shm_open(name, O_RDWR | O_CREAT | O_EXCL, 0600);
		
		fchmod(fd,0777);
        if (fd != -1)
            break;
        if (errno != EEXIST)
            return NULL_HANDLE;
    }
    int ret = ftruncate(fd, z_size);
    close(fd);
    return handle;
}

VOID x_smem_block_free(HANDLE_T handle)
{
    char name[HANDLE_NAME_LENGTH];
    int ret;

    HANDLE_TO_NAME(name, handle);
    ret = shm_unlink(name);
    ASSERT(ret == 0);
}

VOID *x_smem_block_map(HANDLE_T handle)
{
    char name[HANDLE_NAME_LENGTH];
    struct stat buf;
    int fd;
    void *addr;
    PSMEM_MAP item = malloc(sizeof(SMEM_MAP));

    if (item == NULL) return NULL;
    HANDLE_TO_NAME(name, handle);
    fd = shm_open(name, O_RDWR, 0600);
    if (fd == -1)
    {
        free(item);
        return NULL;
    }
    VERIFY(fstat(fd, &buf) == 0);
    addr = mmap(NULL, buf.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED)
    {
        close(fd);
        free(item);
        return NULL;
    }
    item->fd = fd;
    item->addr = addr;
    item->size = buf.st_size;

    VERIFY(pthread_mutex_lock(&mutex) == 0);
    list_add_tail(&item->list, &smem_list);
    VERIFY(pthread_mutex_unlock(&mutex) == 0);

    return addr;
}

static int x_smem_block_unmap_impl(VOID *pv_mem_block)
{
    PSMEM_MAP item;
    int ret;

    if (pv_mem_block == NULL) return 0;
    VERIFY(pthread_mutex_lock(&mutex) == 0);
    list_for_each_entry(item, &smem_list, list)
    {
        if (item->addr == pv_mem_block)
        {
            list_del(&item->list);
            VERIFY(pthread_mutex_unlock(&mutex) == 0);
            ret = munmap((void *)((unsigned long)item->addr), item->size);
            close(item->fd);
            free(item);
            return ret;
        }
    }
    VERIFY(pthread_mutex_unlock(&mutex) == 0);
    return -1;
}

VOID x_smem_block_unmap(VOID *pv_mem_block)
{
    VERIFY(x_smem_block_unmap_impl(pv_mem_block) == 0);
}

VOID *x_skmem_block_map(HANDLE_T handle)
{
    if (handle < SMEM_HANDLE_MAX)
        return x_smem_block_map(handle);
    return x_kmem_block_map(handle);
}

VOID *x_skmem_block_multimap(int n, HANDLE_T handles[])
{
    int i;

    if (n < 1) return NULL;
    else if (n == 1) return x_skmem_block_map(handles[0]);

    for (i = 0; i < n; i++)
        if (handles[i] < SMEM_HANDLE_MAX)
            return NULL;
    return x_kmem_block_multimap(n, handles);
}

VOID x_skmem_block_unmap(VOID *pv_mem_block)
{
    if (x_smem_block_unmap_impl(pv_mem_block) != 0)
        x_kmem_block_unmap(pv_mem_block);
}


/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <execinfo.h>


// #define MEMORYZONE_FOUND_ALLOCATOR_BDP
// #define MEMORYZONE_THRSHD_BDP 2  /*   memory*/


#ifdef _BDPPROG
#include "x_assert.h"
#else
#include <assert.h>
#define ASSERT(X) assert(X)
#define VERIFY(X) ((X) ? (void)(0) : assert(0 && #X))
#endif

#include "x_kmem.h"
#include "kmem.h"

#if CONFIG_SYS_MEM_WASTE_WARNING
#include "x_printf.h"

#ifndef PAGE_SHIFT
#define PAGE_SHIFT      12
#endif // PAGE_SHIFT

static inline int get_order(unsigned long size)
{
	int order;

	size = (size - 1) >> (PAGE_SHIFT - 1);
	order = -1;
	do {
		size >>= 1;
		order++;
	} while (size);
	return order;
}
#endif


#ifdef MEMORYZONE_FOUND_ALLOCATOR_BDP

static void dump_stack(void)
{
    void *trace[32];
    char **messages;
    int i, trace_size;

    trace_size = backtrace(trace, 32);
    messages = backtrace_symbols(trace, trace_size);
    if (messages != NULL)
    {
        printf("backtrace:\n");
        for (i = 1; i < trace_size; i++)
            printf("%s\n", messages[i]);
        free(messages);
    }
}

static  void memoryzone_test_fun(int size)
{
     if((size > (4096 << MEMORYZONE_THRSHD_BDP))){
     //if((size <= (4096 << MEMORYZONE_THRSHD_BDP))&& (size > 0 )){
			printf( "-----------test-------kmem_user.c\n");
			dump_stack();
    }

}
#endif


#ifndef PAGE_SIZE
#define PAGE_SIZE       4096
#endif // PAGE_SIZE
#ifndef PAGE_MASK
#define PAGE_MASK       (~(PAGE_SIZE - 1))
#endif // PAGE_MASK

struct list_head {
	struct list_head *next, *prev;
};

static inline void list_add_tail(struct list_head *new, struct list_head *head)
{
	struct list_head *last;

	last = head->prev;
	head->prev = new;
	new->next = head;
	new->prev = last;
	last->next = new;
}

static inline void list_del(struct list_head *entry)
{
	entry->prev->next = entry->next;
	entry->next->prev = entry->prev;
}

#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})

#define list_entry(ptr, type, member) \
	container_of(ptr, type, member)

#define list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

typedef struct _KMEM_MAP
{
    struct list_head list;
    struct _KMEM_MAP *owner;
    HANDLE_T handle;
    size_t size;
    void *addr;
} KMEM_MAP, *PKMEM_MAP;

static int fd_kmem;
static struct list_head kmem_list = { &kmem_list, &kmem_list };
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

static HANDLE_T x_kmem_block_handle(VOID *pv_mem)
{
    struct list_head *t;
    VERIFY(pthread_mutex_lock(&mutex) == 0);
    list_for_each(t, &kmem_list)
    {
        PKMEM_MAP item = list_entry(t, KMEM_MAP, list);
        if (item->addr == pv_mem)
        {
            VERIFY(pthread_mutex_unlock(&mutex) == 0);
            return item->handle;
        }
    }
    VERIFY(pthread_mutex_unlock(&mutex) == 0);
    return NULL_HANDLE;
}

VOID *x_kmem_alloc(SIZE_T z_size)
{
#ifdef MEMORYZONE_FOUND_ALLOCATOR_BDP
	memoryzone_test_fun(z_size);
#endif
    return x_kmem_aligned_alloc(z_size, 32);
}

VOID *x_vmem_alloc(SIZE_T z_size)
{
    return x_vmem_aligned_alloc(z_size, 32);
}

#if 1 // CONFIG_ONEZONE_MEM_ALLOC_NEW_POLICY

VOID *x_kmem_alloc_onezone_pool(SIZE_T z_size)
{
#ifdef MEMORYZONE_FOUND_ALLOCATOR_BDP
	memoryzone_test_fun(z_size);
#endif
    return x_kmem_aligned_alloc_onezone_pool(z_size, 32);
}
#endif // CONFIG_ONEZONE_MEM_ALLOC_NEW_POLICY

VOID *x_kmem_calloc(UINT32 ui4_num_element, SIZE_T z_size_element)
{
    SIZE_T z_size = ui4_num_element * z_size_element;
    VOID *pv_mem = x_kmem_alloc(z_size);
    if (pv_mem != NULL)
    {
        bzero(pv_mem, z_size);
    }
    return pv_mem;
}

VOID *x_kmem_realloc(VOID *pv_mem_block, SIZE_T z_new_size)
{
    VOID *pv_new;

    if (pv_mem_block == NULL)
    {
        return x_kmem_alloc(z_new_size);
    }
    if (z_new_size == 0)
    {
        x_kmem_free(pv_mem_block);
        return NULL;
    }
    pv_new = x_kmem_alloc(z_new_size);
    if (pv_new != NULL)
    {
        memcpy(pv_new, pv_mem_block, z_new_size);
        x_kmem_free(pv_mem_block);
    }
    return pv_new;
}

VOID x_kmem_free(VOID *pv_mem_block)
{
    x_kmem_aligned_free(pv_mem_block);
}

VOID x_vmem_free(VOID *pv_mem_block)
{
    x_vmem_aligned_free(pv_mem_block);
}


VOID *x_kmem_aligned_alloc(SIZE_T z_size, UINT32 u4Align)
{
    HANDLE_T handle = x_kmem_block_aligned_alloc(z_size, u4Align);
#if CONFIG_SYS_MEM_WASTE_WARNING
    if (z_size >= PAGE_SIZE)
    {
        if((z_size * 4) < (((1 << get_order(z_size)) << PAGE_SHIFT) * 3))
            Printf("[User %s] size = %d, usage less than 3/4, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
        if((z_size + (256*1024)) < ((1 << get_order(z_size)) << PAGE_SHIFT))
            Printf("[User %s] size = %d, over 256K bytes is unused, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
    }
#endif
    if (handle == NULL_HANDLE)
        return NULL;
    return x_kmem_block_map(handle);
}

VOID *x_vmem_aligned_alloc(SIZE_T z_size, UINT32 u4Align)
{
    HANDLE_T handle = x_vmem_block_aligned_alloc(z_size, u4Align);
    if (handle == NULL_HANDLE)
        return NULL;
    return x_kmem_block_map(handle);
}

#if 1 //CONFIG_ONEZONE_MEM_ALLOC_NEW_POLICY
VOID *x_kmem_aligned_alloc_onezone_pool(SIZE_T z_size, UINT32 u4Align)
{
    HANDLE_T handle = x_kmem_block_aligned_alloc_onezone_pool(z_size, u4Align);
#if CONFIG_SYS_MEM_WASTE_WARNING
    if (z_size >= PAGE_SIZE)
    {
        if((z_size * 4) < (((1 << get_order(z_size)) << PAGE_SHIFT) * 3))
            Printf("[User %s] size = %d, usage less than 3/4, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
        if((z_size + (256*1024)) < ((1 << get_order(z_size)) << PAGE_SHIFT))
            Printf("[User %s] size = %d, over 256K bytes is unused, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
    }
#endif
    if (handle == NULL_HANDLE)
        return NULL;
    return x_kmem_block_map(handle);
}

HANDLE_T x_kmem_block_aligned_alloc_onezone_pool(SIZE_T z_size, UINT32 u4Align)
{
    KMEM_ALIGNED_ALLOC_T i;
    int ret;

	#ifdef MEMORYZONE_FOUND_ALLOCATOR_BDP
		memoryzone_test_fun(z_size);
	#endif

#if CONFIG_SYS_MEM_WASTE_WARNING
    if (z_size >= PAGE_SIZE)
    {
        if((z_size * 4) < (((1 << get_order(z_size)) << PAGE_SHIFT) * 3))
            Printf("[User %s] size = %d, usage less than 3/4, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
        if((z_size + (256*1024)) < ((1 << get_order(z_size)) << PAGE_SHIFT))
            Printf("[User %s] size = %d, over 256K bytes is unused, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
    }
#endif

    i.in.z_size = z_size;
    i.in.u4Align = u4Align;
    ret = ioctl(fd_kmem, IOCTL_KMEM_ALIGNED_ALLOC_ONEZONE_POOL, &i);
    ASSERT(ret == 0);

    return i.out.handle;
}


#endif // #if CONFIG_ONEZONE_MEM_ALLOC_NEW_POLICY

VOID x_kmem_aligned_free(VOID *pv_mem)
{
    HANDLE_T handle = x_kmem_block_handle(pv_mem);
    x_kmem_block_unmap(pv_mem);
    x_kmem_block_aligned_free(handle);
}

VOID x_vmem_aligned_free(VOID *pv_mem)
{
    HANDLE_T handle = x_kmem_block_handle(pv_mem);
    x_kmem_block_unmap(pv_mem);
    x_vmem_block_aligned_free(handle);
}

HANDLE_T x_kmem_block_alloc(SIZE_T z_size)
{
#if CONFIG_SYS_MEM_WASTE_WARNING
    if (z_size >= PAGE_SIZE)
    {
        if((z_size * 4) < (((1 << get_order(z_size)) << PAGE_SHIFT) * 3))
            Printf("[User %s] size = %d, usage less than 3/4, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
        if((z_size + (256*1024)) < ((1 << get_order(z_size)) << PAGE_SHIFT))
            Printf("[User %s] size = %d, over 256K bytes is unused, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
    }
#endif
    return x_kmem_block_aligned_alloc(z_size, 32);
}

HANDLE_T x_kmem_block_sliced_alloc(UINT32 z_size, SIZE_T z_size_element)
{
    return x_kmem_block_sliced_aligned_alloc(z_size, z_size_element, 32);
}

HANDLE_T x_kmem_block_sliced_aligned_alloc(UINT32 z_size, SIZE_T z_size_element, UINT32 u4Align)
{
    KMEM_SLICED_ALIGNED_ALLOC_T i;
    int ret;

    i.in.z_size = z_size;
    i.in.z_size_element = z_size_element;
    i.in.u4Align = u4Align;
    ret = ioctl(fd_kmem, IOCTL_KMEM_SLICED_ALIGNED_ALLOC, &i);
    ASSERT(ret == 0);

    return i.out.handle;
}

VOID x_kmem_block_free(HANDLE_T handle)
{
    x_kmem_block_aligned_free(handle);
}

HANDLE_T x_kmem_block_aligned_alloc(SIZE_T z_size, UINT32 u4Align)
{
    KMEM_ALIGNED_ALLOC_T i;
    int ret;

#ifdef MEMORYZONE_FOUND_ALLOCATOR_BDP
    memoryzone_test_fun(z_size);
#endif

#if CONFIG_SYS_MEM_WASTE_WARNING
    if (z_size >= PAGE_SIZE)
    {
        if((z_size * 4) < (((1 << get_order(z_size)) << PAGE_SHIFT) * 3))
            Printf("[User %s] size = %d, usage less than 3/4, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
        if((z_size + (256*1024)) < ((1 << get_order(z_size)) << PAGE_SHIFT))
            Printf("[User %s] size = %d, over 256K bytes is unused, caller address = %p\n", __FUNCTION__, z_size, __builtin_return_address(0));
    }
#endif

    i.in.z_size = z_size;
    i.in.u4Align = u4Align;
    ret = ioctl(fd_kmem, IOCTL_KMEM_ALIGNED_ALLOC, &i);
    ASSERT(ret == 0);

    return i.out.handle;
}

HANDLE_T x_vmem_block_aligned_alloc(SIZE_T z_size, UINT32 u4Align)
{
    KMEM_ALIGNED_ALLOC_T i;
    int ret;

    i.in.z_size = z_size;
    i.in.u4Align = u4Align;
    ret = ioctl(fd_kmem, IOCTL_VMEM_ALIGNED_ALLOC, &i);
    ASSERT(ret == 0);

    return i.out.handle;
}


VOID x_kmem_block_aligned_free(HANDLE_T handle)
{
    int ret;
    ret = ioctl(fd_kmem, IOCTL_KMEM_ALIGNED_FREE, handle);
    ASSERT(ret == 0);
}

VOID x_vmem_block_aligned_free(HANDLE_T handle)
{
    int ret;
    ret = ioctl(fd_kmem, IOCTL_VMEM_ALIGNED_FREE, handle);
    ASSERT(ret == 0);
}

VOID *x_kmem_block_map(HANDLE_T handle)
{
    unsigned long offset = (unsigned long)handle;
    size_t size = (unsigned long)handle;
    int ret;
    char *addr;
    PKMEM_MAP item = malloc(sizeof(KMEM_MAP));

    if (item == NULL) return NULL;
    ret = ioctl(fd_kmem, IOCTL_KMEM_GET_SIZE, &size);
    ASSERT(ret == 0);
    ret = ioctl(fd_kmem, IOCTL_KMEM_GET_PAGE_OFFSET, &offset);
    ASSERT(ret == 0);
    item->owner = item;
    item->handle = handle;
    item->size = size;

    VERIFY(pthread_mutex_lock(&mutex) == 0);
    ret = ioctl(fd_kmem, IOCTL_KMEM_SET_MMAP_HANDLE, handle);
    ASSERT(ret == 0);
    addr = mmap(NULL, (offset + size + ~PAGE_MASK) & PAGE_MASK, PROT_READ | PROT_WRITE, MAP_SHARED, fd_kmem, 0);
    if(addr == MAP_FAILED)
    {
    	printf("mmap failed, errno(%d), size(%d), handle(%p)\n",
		errno, size, (void *)handle);
    	ASSERT(0);
    }
    addr += offset;
    item->addr = addr;
    list_add_tail(&item->list, &kmem_list);
    VERIFY(pthread_mutex_unlock(&mutex) == 0);

    return addr;
}

VOID *x_kmem_block_multimap(int n, HANDLE_T handles[])
{
    size_t size = 0, offset = 0;
    int i, ret;
    char *addr;
    PKMEM_MAP items;

    ASSERT(n >= 1);
    items = malloc(sizeof(KMEM_MAP) * n);
    if (items == NULL) return NULL;
    for (i = 0; i < n; i++)
    {
        PKMEM_MAP item = &items[i];
        unsigned long offset = (unsigned long)handles[i];
        item->owner = items;
        item->size = (unsigned long)handles[i];
        item->handle = handles[i];
        ret = ioctl(fd_kmem, IOCTL_KMEM_GET_SIZE, &item->size);
        ASSERT(ret == 0 && (item->size & ~PAGE_MASK) == 0);
        ret = ioctl(fd_kmem, IOCTL_KMEM_GET_PAGE_OFFSET, &offset);
        ASSERT(ret == 0 && offset == 0);
        size += item->size;
    }

    addr = mmap(NULL, size, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    ASSERT(addr != MAP_FAILED);
    VERIFY(pthread_mutex_lock(&mutex) == 0);
    for (i = 0; i < n; i++)
    {
        PKMEM_MAP item = &items[i];
        ret = ioctl(fd_kmem, IOCTL_KMEM_SET_MMAP_HANDLE, item->handle);
        ASSERT(ret == 0);
        item->addr = mmap(addr + offset, item->size, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_FIXED, fd_kmem, 0);
        ASSERT(item->addr != MAP_FAILED);
        offset += item->size;
        list_add_tail(&item->list, &kmem_list);
    }
    VERIFY(pthread_mutex_unlock(&mutex) == 0);

    return addr;
}

VOID x_kmem_block_unmap(VOID *pv_mem_block)
{
    struct list_head *t;
    int ret;
    PKMEM_MAP items = NULL;
    size_t size = 0;

    if (pv_mem_block == NULL) return;
    VERIFY(pthread_mutex_lock(&mutex) == 0);
    list_for_each(t, &kmem_list)
    {
        PKMEM_MAP item = list_entry(t, KMEM_MAP, list);
        if (item->addr == pv_mem_block)
        {
            items = item;
            break;
        }
    }

    ASSERT(items != NULL && items->owner == items);
    if (items == NULL || items->owner != items)
    {
        VERIFY(pthread_mutex_unlock(&mutex) == 0);
        return;
    }

    list_for_each(t, &kmem_list)
    {
        PKMEM_MAP item = list_entry(t, KMEM_MAP, list);
        if (item->owner == items)
        {
            list_del(&item->list);
            size += item->size;
        }
    }
    VERIFY(pthread_mutex_unlock(&mutex) == 0);
    ret = munmap((void *)((unsigned long)items->addr & PAGE_MASK),
        (size + ((unsigned long)items->addr & ~PAGE_MASK) + ~PAGE_MASK) & PAGE_MASK);
    ASSERT(ret == 0);
    free(items);
}

static inline unsigned int __clz(unsigned int val)
{
    unsigned int ret;
    asm ("clz\t%0, %1" : "=r" (ret) : "r" (val));
    return ret;
}

SIZE_T x_kmem_calc_slice_size(UINT32 z_size)
{
    SIZE_T i, j, k;
    for (i = 2 * 1024 * 1024; i > 256 * 1024; i >>= 1)
    {
        if (i > z_size) continue;
        j = z_size & (i - 1);
        k = 0x80000000u >> __clz(j);
        if (k < j) k <<= 1;
        if (k - j < 128 * 1024)
            break;
    }
    return i;
}

#ifdef _BDPPROG

INT32 kmem_init(void)
{
    fd_kmem = open(DEV_KMEM, O_RDWR);
    if (fd_kmem == -1)
    {
        return -1;
    }
    return 0;
}

#else

static void __attribute__((constructor)) kmem_init(void)
{
    fd_kmem = open(DEV_KMEM, O_RDWR);
    ASSERT(fd_kmem != -1);
}

#endif

#if 1//CONFIG_ONEZONE_MEM_ALLOC_NEW_POLICY
VOID *x_vmem_alloc_handle(SIZE_T z_size, HANDLE_T *pv_hdl, VOID **ppv_krn_mem)
{
    KMEM_ALLOC_HANDLE_T i;
    VOID *pv_usr;
    int ret;

    i.u4_size = z_size;

    ret = ioctl(fd_kmem, IOCTL_VMEM_ALLOC_HANDLE, &i);
    ASSERT(ret == 0);

    *pv_hdl = i.h_handle;
    *ppv_krn_mem = i.pv_krn_mem;

    pv_usr = x_kmem_block_map(i.h_handle);

    return pv_usr;
}

VOID x_vmem_free_handle(VOID *pv_usr_mem, VOID *pv_krn_mem, HANDLE_T h_hdl)
{
    KMEM_FREE_HANDLE_T i;
    int ret;

    i.pv_krn_mem = pv_krn_mem;
    i.h_handle = h_hdl;

    x_kmem_block_unmap(pv_usr_mem);

    ret = ioctl(fd_kmem, IOCTL_VMEM_FREE_HANDLE, &i);
    ASSERT(ret == 0);
}
#endif


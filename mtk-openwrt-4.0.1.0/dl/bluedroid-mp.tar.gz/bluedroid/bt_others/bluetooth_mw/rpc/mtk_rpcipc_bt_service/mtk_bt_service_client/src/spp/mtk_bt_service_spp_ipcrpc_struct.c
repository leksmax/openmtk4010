/* This source file was automatically created by the */
/* tool 'MTK RPC Description tool', 'Version 1.10' on 'Wed Jun 21 18:10:06 2017'. */
/* Do NOT modify this source file. */



/* Start of source pre-amble file 'preamble_file.h'. */

#include "rpc.h"
#include "mtk_bt_service_spp_wrapper.h"

/* End of source pre-amble file 'preamble_file.h'. */





static const RPC_DESC_T* at_rpc_desc_list [] =
{
};

const RPC_DESC_T* __rpc_get_spp_desc__ (UINT32  ui4_idx)
{
  return ((ui4_idx < 0) ? at_rpc_desc_list [ui4_idx] : NULL);
}



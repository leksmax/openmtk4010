/* This header file was automatically created by the */
/* tool 'MTK RPC Description tool', 'Version 1.10' on 'Wed Jun 21 18:10:06 2017'. */
/* Do NOT modify this header file. */

#ifndef _MTK_BT_SERVICE_SPP_IPCRPC_STRUCT__H_
#define _MTK_BT_SERVICE_SPP_IPCRPC_STRUCT__H_




/* Start of header pre-amble file 'preamble_file.h'. */

#include "rpc.h"
#include "mtk_bt_service_spp_wrapper.h"

/* End of header pre-amble file 'preamble_file.h'. */



extern const RPC_DESC_T* __rpc_get_spp_desc__ (UINT32  ui4_idx);


#endif


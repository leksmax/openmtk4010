
#ifndef _BT_DBG_CONFIG_HFP_H_
#define _BT_DBG_CONFIG_HFP_H_

enum
{
    HFP_CMD_START = DBG_HFP << MOD_LOCATION & 0xFF000000,

    HFP_CMD_END
};

#endif


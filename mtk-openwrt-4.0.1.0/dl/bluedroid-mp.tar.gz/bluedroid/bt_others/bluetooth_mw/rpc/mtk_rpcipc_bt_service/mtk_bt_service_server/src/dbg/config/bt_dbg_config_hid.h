
#ifndef _BT_DBG_CONFIG_HID_H_
#define _BT_DBG_CONFIG_HID_H_

enum
{
    HID_CMD_START = DBG_HID << MOD_LOCATION & 0xFF000000,

    HID_CMD_END
};

#endif


/* This header file was automatically created by the */
/* tool 'MTK RPC Description tool', 'Version 1.10' on 'Thu Jun 22 14:11:32 2017'. */
/* Do NOT modify this header file. */

#ifndef _MTK_BT_SERVICE_DBG_HANDLE__H_
#define _MTK_BT_SERVICE_DBG_HANDLE__H_

int c_rpc_reg_mtk_bt_service_dbg_op_hndlrs(VOID);

#endif


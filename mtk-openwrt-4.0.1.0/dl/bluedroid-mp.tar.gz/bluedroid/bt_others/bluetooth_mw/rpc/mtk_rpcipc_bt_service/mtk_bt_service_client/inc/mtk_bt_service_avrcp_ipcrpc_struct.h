/* This header file was automatically created by the */
/* tool 'MTK RPC Description tool', 'Version 1.10' on 'Fri Mar 24 08:08:25 2017'. */
/* Do NOT modify this header file. */

#ifndef _MTK_BT_SERVICE_AVRCP_IPCRPC_STRUCT__H_
#define _MTK_BT_SERVICE_AVRCP_IPCRPC_STRUCT__H_




/* Start of header pre-amble file 'preamble_file.h'. */

#include "rpc.h"
#include "mtk_bt_service_avrcp_wrapper.h"
#include "mtk_bt_service_avrcp_wrapper.h"
#include "u_bt_mw_avrcp.h"
#include "u_bt_mw_common.h"


/* End of header pre-amble file 'preamble_file.h'. */


#define RPC_DESC_avrcp_medioInfo_t  (__rpc_get_avrcp_desc__ (0))


#define RPC_DESC_bt_player_status_values_t  (__rpc_get_avrcp_desc__ (1))


#define RPC_DESC_bt_player_settings_t  (__rpc_get_avrcp_desc__ (2))


#define RPC_DESC_bt_register_notification_t  (__rpc_get_avrcp_desc__ (3))



extern const RPC_DESC_T* __rpc_get_avrcp_desc__ (UINT32  ui4_idx);


#endif


#include "rpc.h"
#include "mtk_bt_service_hidh_wrapper.h"
#include "u_bt_mw_common.h"

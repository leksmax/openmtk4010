/* This source file was automatically created by the */
/* tool 'MTK RPC Description tool', 'Version 1.10' on 'Thu Jun 22 14:11:32 2017'. */
/* Do NOT modify this source file. */



/* Start of source pre-amble file 'preamble_file.h'. */

#include <fcntl.h>

#include "rpc.h"

#include "config/bt_dbg_config.h"
#include "mtk_bt_service_dbg.h"

int gap_var[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};

int gap_var_test(int array_index, int offset, char *buff, int length)
{
    if (offset >= 1)
    {
        return 0;
    }

    sprintf(buff, "%d\n", gap_var[array_index]);
    return offset + 1;
}

typedef struct
{
    int int_demo;
    char str_demo[256];
}str_test;

str_test gap_str[16] =
{
    {1, "aaa"},
    {2, "bbb"},
    {3, "ccc"},
    {4, "ddd"},
    {5, "eee"},
    {6, "fff"},
    {7, "ggg"},
    {8, "hhh"},
    {9, "iii"},
    {10, "jjj"},
    {11, "kkk"},
    {12, "lll"},
    {13, "mmm"},
    {14, "nnn"},
    {15, "ooo"},
    {16, "ppp"},
};

int gap_str_test(int array_index, int offset, char *buff, int length)
{
    switch(offset)
    {
        case 0:
            sprintf(buff, "%d\n", gap_str[array_index].int_demo);
            break;
        case 1:
            sprintf(buff, "%s\n", gap_str[array_index].str_demo);
            break;
        default:
            return 0;
    }

    return offset + 1;
}

static int bt_dbg_read(int cmd, int array_index)
{
    int m_index = 0, s_index = 0, ret_index = 0, fd = 0;
    char buff[BUFF_LEN] = {0};

    for (m_index = 0; NULL != m_cmd[m_index].c_mod; m_index++)
    {
        if (m_cmd[m_index].d_mod == (cmd >> MOD_LOCATION & 0xFF))
            break;
    }

    if (NULL == m_cmd[m_index].c_mod)
    {
        printf("Input module error!");
        return -1;
    }

    for (s_index = 0; 0 != m_cmd[m_index].s_cmd[s_index].cmd; s_index++)
    {
        if (m_cmd[m_index].s_cmd[s_index].cmd == cmd)
            break;
    }

    if (0 == m_cmd[m_index].s_cmd[s_index].cmd)
    {
        printf("Input cmd error!");
        return -1;
    }

    fd = open(BT_DBG_R_FILE, O_RDWR | O_CREAT , 0777);
    if (fd < 0)
    {
        printf("%s open bt-dbg-r file failed %d", __func__, fd);
        return -1;
    }

    ftruncate(fd, 0);
    lseek(fd, 0, SEEK_SET);

    memset(buff, 0, BUFF_LEN - 1);
    buff[0] = '&';
    ret_index = m_cmd[m_index].s_cmd[s_index].func_r(array_index, 0, &buff[1], BUFF_LEN - 1);
    while(0 != ret_index)
    {
        write(fd, buff, strlen(buff));

        memset(buff, 0, BUFF_LEN - 1);
        buff[0] = '&';
        ret_index = m_cmd[m_index].s_cmd[s_index].func_r(array_index, ret_index, &buff[1], BUFF_LEN - 1);
    }

    close(fd);
    return 0;
}

static int bt_dbg_write(int cmd, int array_index)
{
    int m_index = 0, s_index = 0;

    for (m_index = 0; NULL != m_cmd[m_index].c_mod; m_index++)
    {
        if (m_cmd[m_index].d_mod == (cmd >> MOD_LOCATION & 0xFF))
            break;
    }

    if (NULL == m_cmd[m_index].c_mod)
    {
        printf("Input module error!");
        return -1;
    }

    for (s_index = 0; 0 != m_cmd[m_index].s_cmd[s_index].cmd; s_index++)
    {
        if (m_cmd[m_index].s_cmd[s_index].cmd == cmd)
            break;
    }

    if (0 == m_cmd[m_index].s_cmd[s_index].cmd)
    {
        printf("Input cmd error!");
        return -1;
    }

    return 0;
}

int x_mtkapi_bt_dbg_op(int cmd, int op, int index)
{
    if (DBG_OP_READ == op)
    {
        bt_dbg_read(cmd, index);
    }

    if (DBG_OP_WRITE == op)
    {
        bt_dbg_write(cmd, index);
    }

    return 0;
}


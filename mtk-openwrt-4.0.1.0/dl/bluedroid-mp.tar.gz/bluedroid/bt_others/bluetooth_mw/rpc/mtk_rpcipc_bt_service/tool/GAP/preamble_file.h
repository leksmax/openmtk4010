#include "rpc.h"
#include "u_bluetooth.h"
#include "mtk_bt_service_gap_wrapper.h"
#include "u_bt_mw_common.h"
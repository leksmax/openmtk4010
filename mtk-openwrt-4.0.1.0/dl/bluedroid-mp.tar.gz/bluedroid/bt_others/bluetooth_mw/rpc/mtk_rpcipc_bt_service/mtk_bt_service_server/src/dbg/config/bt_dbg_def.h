
#ifndef _BT_DBG_DEF_H_
#define _BT_DBG_DEF_H_

#if defined(BT_RPC_DBG_SERVER) || defined(BT_RPC_DBG_CLIENT)
#define MOD_LOCATION 24
#define BT_DBG_R_FILE "/tmp/bt-dbg-r"
#define BT_DBG_W_FILE "/tmp/bt-dbg-w"
#define HEAD "<"
#define TYPE "@"
#define ARRY "#"
#define NAME "$"
#define MEMB "^"
#define TAIL ">"

#if defined(BT_RPC_DBG_SERVER)
typedef int (*DBG_R)(int array_index, int offset, char *buff, int length);
#endif

typedef enum
{
    DBG_START = 0,

    DBG_GAP,
    DBG_L2CAP,
    DBG_GATT,
    DBG_A2DP,
    DBG_HID,
    DBG_AVRCP,
    DBG_HFP,
    DBG_SPP,

    DBG_END
}DBG_MOD;

enum
{
    DBG_OP_NONE,
    DBG_OP_READ,
    DBG_OP_WRITE
};

typedef struct {
    int     cmd;
#if defined(BT_RPC_DBG_SERVER)
    DBG_R   func_r;
#endif
#if defined(BT_RPC_DBG_CLIENT)
    char    *doc;
#endif
}SUB_CMD;

typedef struct
{
    char    *c_mod;
    DBG_MOD d_mod;
    SUB_CMD *s_cmd;
    int     length;
    char    *doc;
}MAIN_CMD;

typedef struct
{
    char buf[256];
    int  length;
}BT_RPC_DBG_BUF;

#ifndef NULL
#define NULL 0
#endif

#define GAP_CMD_NUM     (GAP_CMD_END - GAP_CMD_START)
#define L2CAP_CMD_NUM   (L2CAP_CMD_END - L2CAP_CMD_START)
#define GATT_CMD_NUM    (GATT_CMD_END - GATT_CMD_START)
#define A2DP_CMD_NUM    (A2DP_CMD_END - A2DP_CMD_START)
#define HID_CMD_NUM     (HID_CMD_END - HID_CMD_START)
#define AVRCP_CMD_NUM   (AVRCP_CMD_END - AVRCP_CMD_START)
#define HFP_CMD_NUM     (HFP_CMD_END - HFP_CMD_START)
#define SPP_CMD_NUM     (SPP_CMD_END - SPP_CMD_START)

#endif

#endif


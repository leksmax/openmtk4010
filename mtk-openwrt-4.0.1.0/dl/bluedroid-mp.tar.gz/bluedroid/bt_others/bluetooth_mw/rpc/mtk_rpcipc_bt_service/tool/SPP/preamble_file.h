#include "rpc.h"
#include "mtk_bt_service_spp_wrapper.h"
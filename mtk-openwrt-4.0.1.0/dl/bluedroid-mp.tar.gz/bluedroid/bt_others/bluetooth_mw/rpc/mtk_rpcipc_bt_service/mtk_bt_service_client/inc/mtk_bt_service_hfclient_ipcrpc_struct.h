/* This header file was automatically created by the */
/* tool 'MTK RPC Description tool', 'Version 1.10' on 'Fri Mar 24 08:08:35 2017'. */
/* Do NOT modify this header file. */

#ifndef _MTK_BT_SERVICE_HFCLIENT_IPCRPC_STRUCT__H_
#define _MTK_BT_SERVICE_HFCLIENT_IPCRPC_STRUCT__H_




/* Start of header pre-amble file 'preamble_file.h'. */

#include "rpc.h"
#include "mtk_bt_service_hfclient_wrapper.h"
#include "u_bt_mw_hfclient.h"
#include "u_bluetooth.h"


/* End of header pre-amble file 'preamble_file.h'. */


#define RPC_DESC_BT_HFCLIENT_CURRENT_CALLS_T  (__rpc_get_hfclient_desc__ (0))


#define RPC_DESC_BT_HFCLIENT_VOLUME_CHANGE_T  (__rpc_get_hfclient_desc__ (1))


#define RPC_DESC_BT_HFCLIENT_CMD_COMPLETE_T  (__rpc_get_hfclient_desc__ (2))


#define RPC_DESC_BT_HFCLIENT_SUBSCRIBER_INFO_T  (__rpc_get_hfclient_desc__ (3))



extern const RPC_DESC_T* __rpc_get_hfclient_desc__ (UINT32  ui4_idx);


#endif


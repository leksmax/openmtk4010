#!/bin/sh
make -C ipt uninstall

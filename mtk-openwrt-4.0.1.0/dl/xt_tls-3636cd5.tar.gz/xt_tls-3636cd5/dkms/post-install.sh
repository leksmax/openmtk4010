#!/bin/sh
make -C ipt
make -C ipt install
